package ShipRocket.SR;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Email {




	WebDriver driver;

	
		/*yoplink :  http://www.yopmail.net/en/
		emailSearchBox : //input[@id='login']
		checkInboxBtn : //input[@class='sbut']
		checkNewMailBtn : //span[@class='slientext'][contains(text(),'Check')]
*/}
